import{l as o,a as r}from"../chunks/CcKyi5F4.js";export{o as load_css,r as start};
